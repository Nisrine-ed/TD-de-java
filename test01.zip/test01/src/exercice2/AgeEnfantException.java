package exercice2;

public class AgeEnfantException extends Exception {
	
	
	public AgeEnfantException(String message)
	{
		super(message);
    }
	
	
}
