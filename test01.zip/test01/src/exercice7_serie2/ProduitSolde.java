package exercice7_serie2;

public interface ProduitSolde {
	
	public void lancer_solde(double pourcentage);
	
	public void terminer_solde(double pourcentage);

}
