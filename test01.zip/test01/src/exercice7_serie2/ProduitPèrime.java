package exercice7_serie2;

import java.util.Date;

public interface ProduitP�rime {
	
	public Date datep�remption();
	public int jours_restants();

}
