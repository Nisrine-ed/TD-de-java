package exercice1;

import java.lang.Exception ;

@SuppressWarnings("serial")
public class PileVide extends Exception {
	
	public PileVide(String ms) { 
		super(ms); 
	}

}
