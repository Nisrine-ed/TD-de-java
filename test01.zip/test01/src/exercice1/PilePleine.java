package exercice1;

import java.lang.Exception ;
@SuppressWarnings("serial")
public class PilePleine extends Exception {

	public PilePleine(String ms) {
		
		super(ms);
	}

	


}
