package exercice4;

public class AdresseIPException extends Exception {
	

	public AdresseIPException(String s){
	    super(s);
	}


}
